import 'package:flutter/material.dart';
// Uncomment lines 7 and 10 to view the visual layout at runtime.
// import 'package:flutter/rendering.dart' show debugPaintSizeEnabled;

void main() {
  // debugPaintSizeEnabled = true;
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget titleSection = Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            /*1*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*2*/
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    'El Monte Tai, la montaña sagrada de China',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  'Shandong, China.',
                  style: TextStyle(
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
          /*3*/
          Icon(
            Icons.star,
            color: Colors.red[500],
          ),
          Text('80/100'),
        ],
      ),
    );

    Color color = Theme.of(context).primaryColor;

    Widget buttonSection = Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildButtonColumn(color, Icons.call, 'Contacto'),
          _buildButtonColumn(color, Icons.near_me, 'Mapa'),
          _buildButtonColumn(color, Icons.share, 'Compartir'),
        ],
      ),
    );

    Widget textSection = Container(
      padding: const EdgeInsets.all(32),
      child: Text(
        'El Monte Tai es una de las montañas sagradas del taoísmo, que es una de las religiones mayoritarias en China. Aunque de hecho, el taoísmo no es propiamente una religión, sino más bien un conjunto de enseñanzas y doctrinas a seguir si uno quiere vivir con rectitud. Sería más exacto decir que se trata de una filosofía, que una religión. El taoísmo tuvo su origen en las ideas del filósofo chino Lao-Tse, y su símbolo es el archiconocido ying-yang. De hecho, la palabra “tao” en chino, significa camino, así que etimológicamente, el taoísmo, sería algo así como la “enseñanza del camino”.',
        softWrap: true,
      ),
    );

    return MaterialApp(
      title: 'Monte tai',
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red[500],
          title: Text('El Monte Taishan'),
        ),
        body: ListView(
          children: [
            Image.asset(
              'images/tai.jpg',
              width: 600,
              height: 240,
              fit: BoxFit.cover,
            ),
            titleSection,
            buttonSection,
            textSection,
          ],
        ),
      ),
    );
  }

  Column _buildButtonColumn(Color color, IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color),
        Container(
          margin: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}